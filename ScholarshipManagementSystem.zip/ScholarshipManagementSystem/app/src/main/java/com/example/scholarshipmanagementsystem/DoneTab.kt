package com.example.scholarshipmanagementsystem

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class DoneTab : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.done_tab)
    }
}